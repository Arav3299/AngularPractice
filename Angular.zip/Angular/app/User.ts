export class User {
    name: any;
    email: any;
    number: any;
    pass:any;
    cpass:any;

    constructor(name:String,email: String,number: Number,pass:String,cpass:String){ 
        
    }
}