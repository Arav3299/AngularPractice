export class Employee{
   
    id:number | undefined;  
    employeeId !:String;
    country !: String;
    mobileNumber !:String;
    name !:String;

    constructor(id:number,employeeId: String,country: String,mobileNumber:String,name:String){ 
        
    }

}